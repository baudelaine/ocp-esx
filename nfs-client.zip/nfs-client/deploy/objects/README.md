The objects in this directory are the same as in the parent except split up into one file per object for certain users' convenience.
